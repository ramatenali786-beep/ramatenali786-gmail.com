Websnap Capture
===============

Snap ID: c2932540-b247-40d1-b498-99fd91272b9c
URL: https://ais-pre-ebyt73ovbq2g7ojgvzuymx-712566512734.asia-east1.run.app.
Pages: 1
Assets: 0
Captured: 2026-04-17T14:28:12.364Z

Files:
- *.html - Captured pages with navigation
- state-tree.json - Navigation tree structure
- _assets/ - Captured assets (CSS, images, fonts)
- *.jpg - Screenshots (available separately)

To view:
1. Extract this ZIP
2. Open any .html file in a browser
3. Click links to navigate between captured states
4. All assets are included for offline viewing